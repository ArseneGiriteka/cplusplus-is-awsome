//#pragma once
#ifndef  _FONCTIONS_H
#define _FONCTIONS_H

using namespace std;

#include <iostream>
#include <string>

//std::string melangerLettres(std::string mot);
string melangerLettres(string mot);

#endif // ! _FONCTIONS_H
