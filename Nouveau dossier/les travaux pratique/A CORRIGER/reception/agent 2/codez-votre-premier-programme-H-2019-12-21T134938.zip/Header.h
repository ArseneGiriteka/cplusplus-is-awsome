#pragma once
#include <string>

bool caseInsensitiveStringCompare(const std::string& str1, const std::string& str2);